#include <thread>
#include <iostream>
#include <semaphore>

using namespace std;

#define MSG_COUNT 3

binary_semaphore sem1(0);
binary_semaphore sem2(0);

void a1() {
    for (int i = 0; i < MSG_COUNT; ++i) {
        cout << "Ejecutando a1 (A)\n";
        this_thread::sleep_for(100ms);
    }
}

void b1() {
    for (int i = 0; i < MSG_COUNT; ++i) {
        cout << "Ejecutando b1 (B)\n";
        this_thread::sleep_for(200ms);
    }
}

void a2() {
    for (int i = 0; i < MSG_COUNT; ++i) {
        cout << "Ejecutando a2 (A)\n";
        this_thread::sleep_for(500ms);
    }
}

void b2(){
    for (int i = 0; i < MSG_COUNT; ++i) {
        cout << "Ejecutando b2 (B)\n";
        this_thread::sleep_for(10ms);
    }
}

void A() {
    a1();
    sem1.release();
    sem2.acquire();
    a2();
}

void B() {
    b1();
    sem2.release();
    sem1.acquire();
    b2();
}

int main() {
    thread t1(A);
    thread t2(B);

    t1.join();
    t2.join();

    return 0;
}