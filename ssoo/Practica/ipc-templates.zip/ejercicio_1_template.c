#include <stdio.h>   // printf()
#include <stdlib.h>  // exit()
#include <unistd.h>  // fork() pipe() write() read()
#include "dado.h"    // tirar_dado()

// Constantes 0 / 1 para READ / WRITE
enum { READ, WRITE };
// Constantes 0 / 1 para LESTER / ELIZA
enum { LESTER, ELIZA };

// Variables globales

void lester() {
  // Tiro el dado
  // Le informo el resultado a Humberto
}

void eliza() {
  // Tiro el dado
  // Le informo el resultado a Humberto
}

int main(int argc, char const* argv[]) {
  // Creo los pipes

  // Creo a Lester

  // Creo a Eliza

  // Recibo el dado de Lester

  // Recibo el dado de Eliza

  // Anuncio al ganador

  return 0;
}
